// ============================================================================
// Sable V1.0 - VLF metal detector
// Main program
// Graham Oliver
// 10/08/2023
// ============================================================================

#include "system.h"
#include "parms.h"
#include "timing.h"
#include "encoder.h"
#include "lcd.h"
#include "dsp.h"


//	---------------------------------------------------------------------------
//	Core #0 main program.
//	Initialises all sub-systems which run on Core #0;
//	Then launches the 2nd core to handle the DSP;
//	And finally enters the LCD 'run' display loop.
//	---------------------------------------------------------------------------
int main() {
	sys_init();
	parms_restore();
	queues_init();
	timing_init();
	encoder_init();
	audio_init();
	lcd_init();
	multicore_launch_core1(core1_main);
	lcd_run();
}


//	---------------------------------------------------------------------------
//	Core #1 main program
//	Used for DSP to control VDI and audio
// ----------------------------------------------------------------------------
void core1_main() {
	dsp_init();
	dsp_run();
}