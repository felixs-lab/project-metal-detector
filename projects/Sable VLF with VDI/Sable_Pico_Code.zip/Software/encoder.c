// ============================================================================
// Sable V1.0 - VLF metal detector
// Rotary encoder driver 
// Graham Oliver
// 11/08/2023
// ============================================================================

#include "encoder.h"

uint debounce_offset;
uint pha_debounce_sm;
uint phb_debounce_sm;
uint sel_debounce_sm;


// Function to initialise the encoder driver
// -----------------------------------------
void encoder_init(void) {

	// Add the debounce progam
	debounce_offset = pio_add_program(pio0, &debounce_program);
	
	// Initialise 3 instances of it for the PHA, PHB & SEL encoder switches
	pha_debounce_sm = pio_claim_unused_sm(pio0, true);
	phb_debounce_sm = pio_claim_unused_sm(pio0, true);
	sel_debounce_sm = pio_claim_unused_sm(pio0, true);
	debounce_program_init(pio0, pha_debounce_sm, debounce_offset, 250.0f, PHA_PIN);
	debounce_program_init(pio0, phb_debounce_sm, debounce_offset, 250.0f, PHB_PIN);
	debounce_program_init(pio0, sel_debounce_sm, debounce_offset, 500.0f, SEL_PIN);

	// Register a handler and enable interrupts from the debounced encoder signals
	irq_set_exclusive_handler(PIO0_IRQ_0, encoder_handler);
	pio0_hw->inte0 = PIO_IRQ0_INTE_SM0_BITS;
	irq_set_enabled(PIO0_IRQ_0, true);
}

// Encoder interrupt handler
// -------------------------
void encoder_handler(void) {
	static bool pha_ = true;
	static bool phb_ = true;
	static bool sel_ = true;
	static uint32_t timestamp_ = 0;
	static uint32_t clicked_time = 0;
	uint32_t timestamp;
	bool pha = get_state(pha_debounce_sm);
	bool phb = get_state(phb_debounce_sm);
	bool sel = get_state(sel_debounce_sm);
	bool up = false;
	bool down = false;
	bool click = false;
	bool double_click = false;

	if (!pha && !phb) {
		if (!pha_ && phb_) {
			down = true;
		} else if (pha_ & !phb_) {
			up = true;
		}
	}

	if (sel_ == !sel) {
		timestamp = time_us_32();
		if (sel) {
			if (timestamp - timestamp_ <= 200000) {
				if (timestamp - clicked_time <= 400000) {
					double_click = true;
				} else {
					clicked_time = timestamp;
					click = true;
				}
			}
		}
		timestamp_ = timestamp;
	}

	pha_ = pha;
	phb_ = phb;
	sel_ = sel;

	// Pass the encoder commands onto the encoder processor
	if (up || down || click || double_click) {
		encoder_process(up, down, click, double_click);
	}

	// Re-enable the interrupt
	hw_set_bits(&pio0->irq, 1u);
}

// Function to read the debounced state based on PIO PC location
// -------------------------------------------------------------
bool get_state(uint sm) {
	uint pc = pio_sm_get_pc(pio0, sm);
	if (pc >= debounce_offset + debounce_border) {
		return true;
	} else {
		return false;
	}
}

// Function to process the encoder commands
// ----------------------------------------
void encoder_process(bool up, bool down, bool click, bool double_click) {
	static uint8_t state = IDLE_STATE;
	static bool parms_edited = false;

	// Processor FSM
	switch (state) {
		case IDLE_STATE :
			if (double_click) {
				gpio_put(LED1_PIN, 1);
				state = R_EDIT_STATE;
			}
		break;

		case R_EDIT_STATE :
			if (up) {
				parm.vars[R_DELAY]++;
			} else if (down) {
				parm.vars[R_DELAY]--;
			}

			if (up || down) {
				parms_edited = true;
				r_set(parm.vars[R_DELAY]);
			}

			if (click) {
				gpio_put(LED1_PIN, 0);
				gpio_put(LED2_PIN, 1);
				state = X_EDIT_STATE;
			}
		break;

		case X_EDIT_STATE :
			if (up) {
				parm.vars[X_DELAY]++;
			} else if (down) {
				parm.vars[X_DELAY]--;
			}

			if (up || down) {
				parms_edited = true;
				x_set(parm.vars[X_DELAY]);
			}

			if (click) {
				gpio_put(LED2_PIN, 0);
				gpio_put(LED3_PIN, 1);
				if (parms_edited) {
					parms_store();
				}
				state = S_EDIT_STATE;
			}
		break;

		case S_EDIT_STATE :
			if (up) {
				parm.vars[THRESH]++;
			} else if (down) {
				parm.vars[THRESH]--;
			}

			if (up || down) {
				parms_edited = true;
				sens_set(parm.vars[THRESH]);
			}

			if (click) {
				gpio_put(LED3_PIN, 0);
				if (parms_edited) {
					parms_store();
				}
				state = IDLE_STATE;
			}
		break;

		default :
			state = IDLE_STATE;
	}
}