// ============================================================================
// Sable V1.0 - VLF metal detector
// Timing functions
// Graham Oliver
// 10/08/2023
// ============================================================================

#include "timing.h"

uint r_sm;
uint x_sm;
uint tx_sm;


// Function to initialise the Timing sub-system
// --------------------------------------------
void timing_init(void) {

	// Add the sample delay program
	uint sample_offset = pio_add_program(pio1, &sample_program);

	// Initialise 2 instances of it for R and X samples
	r_sm = pio_claim_unused_sm(pio1, true);
	x_sm = pio_claim_unused_sm(pio1, true);
	sample_program_init(pio1, r_sm, sample_offset, R_SMPL_PIN, parm.vars[R_DELAY]);
	sample_program_init(pio1, x_sm, sample_offset, X_SMPL_PIN, parm.vars[X_DELAY]);

	// Initialise the sensitivity threshold state machine
	// Essentially this is a 100kHz PWM
	// Note: This uses the 'TX' program from 'Beachmaster'
	uint tx_offset = pio_add_program(pio1, &tx_program);
	tx_sm = pio_claim_unused_sm(pio1, true);
	tx_program_init(pio1, tx_sm, tx_offset, parm.vars[THRESH], 100);

}

// Functions to update the R and X delay values
void r_set(uint delay) {
	sample_program_update(pio1, r_sm, delay);
}

void x_set(uint delay) {
	sample_program_update(pio1, x_sm, delay);
}

// Function to set sensitivity threshold
// -----------------------------------------
void sens_set(uint width) {
	tx_program_update(pio1, tx_sm, width, 100);
}
