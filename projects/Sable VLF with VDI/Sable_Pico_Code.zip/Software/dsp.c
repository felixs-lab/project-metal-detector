// ============================================================================
// Sable V1.0 - VLF metal detector
// Digital signal processing system
// Graham Oliver
// 18/08/2023
// ============================================================================

#include "dsp.h"

#define PI 3.141592654

// DSP initialisation function
// ---------------------------
void dsp_init(void) {

	adc_init();

	// Initialise ADC GPIOs
	adc_gpio_init(RVAL_PIN);
	adc_gpio_init(XVAL_PIN);
	adc_gpio_init(VBAT_PIN);

	// Change to detect view after 2 seconds
	target_entry_t target_entry;
	busy_wait_ms(2000);
	target_entry.id = 0;
	target_entry.level = 0;
	queue_add_blocking(&target_queue, &target_entry);
	uint8_t view = DETECT_VIEW;
	queue_add_blocking(&lcd_view_queue, &view);

}

// Main DSP control loop
// In addition to checking the battery voltage, the target
// R and X levels are also measured and if they are both
// above a threshold then the 'identify' function is called
// --------------------------------------------------------
void dsp_run(void) {
	while(1) {
		check_battery();
		uint16_t rval = get_adc(0);
		uint16_t xval = get_adc(1);
		if (rval > 2600 && xval > 2600) {
			identify();
		}
	}
}

// Function to read an ADC channel
// -------------------------------
uint16_t get_adc(uint channel) {
	adc_select_input(channel);
	return adc_read();
}

// Function to read battery voltage and update display queue accordingly
// ---------------------------------------------------------------------
void check_battery(void) {
	uint8_t battery_voltage = (get_adc(2) * 129)/4096 + 1;
	queue_try_add(&battery_voltage_queue, &battery_voltage);
}

// Function to identify the target
// Note:
// -----
// This is very quick and dirty at the moment to test the concept.
// I expect to make this much more sophisticated with auto offset
// and clipping level detection. Also -ve phase calculation for
// ferrous targets.
// The signal strength indicator also needs considerable work
// -------------------------------
void identify(void) {
	target_entry_t target_entry;
	uint16_t rval;
	uint16_t xval;
	uint32_t r = 0;
	uint32_t x = 0;
	uint32_t cnt = 0;
	uint32_t level;
	uint16_t rpk = 0;
	uint16_t xpk = 0;

	do {
		rval = get_adc(0);
		xval = get_adc(1);
		// Only accumulate samples if signal not clipped
		if (rval < 3959 && xval < 3959) {
			r += rval - 2500;
			x += xval - 2500;
			cnt++;
			printf("Rval = %d: Xval = %d: R = %d: X = %d\n", rval, xval, r, x);
		}
		if (rval > rpk) rpk = rval;
		if (xval > xpk) xpk = xval;
	} while (rval > 2600 && xval > 2600);

	double id = atan((double)r/(double)x);
	printf("ID radians = %f\n", id);
	id = (id * 180) / PI;
	printf("ID degrees = %f\n", id);
	if (rpk > xpk) {
		level = rpk - 2500; 
	} else {
		level = xpk - 2500;
	}
	printf("Level = %d\n", level);
	target_entry.id = (uint8_t)id;
	target_entry.level = (uint8_t)(level/14);
	if (cnt > 50) {
		queue_add_blocking(&target_queue, &target_entry);
	}
}