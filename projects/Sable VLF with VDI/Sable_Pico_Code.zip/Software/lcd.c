// ============================================================================
// Sable V1.0 - VLF metal detector
// LCD display functions
// Graham Oliver
// 17/08/2023
// ============================================================================

#include "lcd.h"

UWORD *display_buffer;

// Initialise the display, returns false if unsuccessful
// -----------------------------------------------------
bool lcd_init(void) {
	DEV_Delay_ms(100);
	if(DEV_Module_Init()!=0){
        return false;
    }
    LCD_1IN8_Init(HORIZONTAL);
    LCD_1IN8_Clear(WHITE);
    UDOUBLE Imagesize = LCD_1IN8_HEIGHT*LCD_1IN8_WIDTH*2;
    if((display_buffer = (UWORD *)malloc(Imagesize)) == NULL) {
        exit(0);
    }
    Paint_NewImage((UBYTE *)display_buffer, LCD_1IN8.WIDTH, LCD_1IN8.HEIGHT, 0, WHITE);
    Paint_SetScale(65);
    Paint_Clear(WHITE);
    Paint_SetRotate(ROTATE_180);
    Paint_Clear(WHITE);
    return(true);
}

// Main display loop
// -----------------
void lcd_run(void) {

	// Initial view is the splash screen
	uint8_t view = SPLASH_VIEW;
	uint8_t previous_view = BLANK_VIEW;

	while(1) {

		// Update view if new one requested
		queue_try_remove(&lcd_view_queue, &view);

		// Display requested view
		switch (view) {
			case SPLASH_VIEW :
				if (previous_view != SPLASH_VIEW) splash_view();
			break;

            case DETECT_VIEW :
                detect_view();
            break;

		}

		// Keep a record of what we have just displayed to
		// avoid re-drawing static displays unnecessarily;
		previous_view = view;
	}
}

// Display a border around the screen
// ----------------------------------
void border(UWORD colour) {
	Paint_DrawRectangle(2, 3, 159, 128, colour, DOT_PIXEL_1X1,DRAW_FILL_EMPTY);
}

// Startup splash screen
// ---------------------
void splash_view(void) {
    Paint_Clear(WHITE);
    border(BLUE);
    Paint_DrawString_EN(50, 5,   "Sable", &Font16, WHITE, BLUE);
    Paint_DrawString_EN(15, 20,  "VLF Detector", &Font16, WHITE, BLUE);
    Paint_DrawString_EN(20, 40,  "Version 1.0", &Font16, WHITE, BLACK);
    Paint_DrawString_EN(20, 55,  "SW Rev  1.0", &Font16, WHITE, BLACK);
    Paint_DrawString_EN(20, 70,  "S/N     001", &Font16, WHITE, BLACK);
    Paint_DrawString_EN(37, 95,  "(c) 2023", &Font16, WHITE, BLUE);
    Paint_DrawString_EN(10, 110, "Graham Oliver", &Font16, WHITE, BLUE);
    LCD_1IN8_Display(display_buffer);
}

// Display main detection view
// ---------------------------
void detect_view(void) {

    uint8_t battery_voltage;
    target_entry_t target_entry;

    // Get data to display via the queueing system
    queue_try_remove(&battery_voltage_queue, &battery_voltage);
    queue_try_remove(&target_queue, &target_entry);

    // Clear the display then update relevant sections
    Paint_Clear(WHITE);
    battery_level(battery_voltage, 105, 126, 110, 55, 8);
    bar_graph(target_entry.level);
	display_number(target_entry.id, 11, 44, false, false);
	Paint_DrawString_EN(3, 5,   "SABLE", &Font12, WHITE, BLACK);
    LCD_1IN8_Display(display_buffer);
}

//  Single segment of 7-segment display
// ------------------------------------
void segment(UWORD X, UWORD Y, uint8_t horizontal, UWORD colour) {
    UWORD x_start;
    UWORD x_end;
    UWORD y_start;
    UWORD y_end;
    if (horizontal) {
        for (UWORD y = Y - SEG_H; y <= Y + SEG_H; y++) {
            if (y > Y) {
                x_start = X + (y - Y);
                x_end = X + SEG_L - (y - Y);
            } else {
                x_start = X + (Y - y);
                x_end = X + SEG_L - (Y - y);
            }
            for (UWORD x = x_start; x <= x_end; x++) {
                Paint_SetPixel(x, y, colour);
            }
        }
    } else {
        for (UWORD x = X - SEG_H; x <= X + SEG_H; x++) {
            if (x > X) {
                y_start = Y + (x - X);
                y_end = Y + SEG_L - (x - X);
            } else {
                y_start = Y + (X - x);
                y_end = Y + SEG_L - (X - x);
            }
            for (UWORD y = y_start; y <= y_end; y++) {
                Paint_SetPixel(x, y, colour);
            }
        }
    }
}

// A full 7-segment digit
// ----------------------
void seven_segment(uint8_t digit, UWORD X, UWORD Y, UWORD colour) {
    switch (digit) {
        case 8 :
            segment(X+1, Y+37, 1, colour);  // Center

        case 0 :
            segment(X+1, Y+74, 1, colour);  // Bottom
            segment(X, Y+1, 0, colour);     // Top left
            segment(X, Y+38, 0, colour);    // Bottom Left

        case 7 :
            segment(X+1, Y, 1, colour);     // Top

        case 1 :
            segment(X+37, Y+1, 0, colour);  // Top Right
            segment(X+37, Y+38, 0, colour); // Bottom Right
        break;

        case 2 :
            segment(X+1, Y, 1, colour);     // Top
            segment(X+1, Y+37, 1, colour);  // Center
            segment(X+1, Y+74, 1, colour);  // Bottom
            segment(X, Y+38, 0, colour);    // Top Right
            segment(X+37, Y+1, 0, colour);  // Bottom Left
        break;

        case 3 :
            segment(X+1, Y, 1, colour);     // Top
            segment(X+1, Y+37, 1, colour);  // Center
            segment(X+1, Y+74, 1, colour);  // Bottom
            segment(X+37, Y+1, 0, colour);  // Top Right
            segment(X+37, Y+38, 0, colour); // Bottom Right
        break;

        case 9 :
            segment(X+1, Y, 1, colour);     // Top
            segment(X+1, Y+74, 1, colour);  // Bottom

        case 4 :
            segment(X+1, Y+37, 1, colour);  // Center
            segment(X, Y+1, 0, colour);     // Top left
            segment(X+37, Y+1, 0, colour);  // Top Right
            segment(X+37, Y+38, 0, colour); // Bottom Right
        break;

        case 6 :
            segment(X, Y+38, 0, colour);    // Bottom Left

        case 5 :
            segment(X+1, Y, 1, colour);     // Top
            segment(X+1, Y+37, 1, colour);  // Center
            segment(X+1, Y+74, 1, colour);  // Bottom
            segment(X, Y+1, 0, colour);     // Top left
            segment(X+37, Y+38, 0, colour); // Bottom Right
        break;

    }
}

// Show a complete multi-digit, seven-segment number
// Shows a maximum value of 999 or 99.9 if decimal set
// ---------------------------------------------------
void display_number(uint16_t number, UWORD X, UWORD Y, bool decimal, bool center) {
	const uint8_t spacing = 55;
	uint8_t offset;

	// Set offset according to 'center' flag
	if (center) {
		offset = spacing/2;;
	} else {
		offset = 0;
	}

	// Constrain number to max displayable x 10
	if (number > 9999) {
		number = 9999;
	}

	// Constrain to the max displayable unless the decimal is set, in
	// which case divide by ten and don't display the decimal point.
	if (number > 999) {
		if (decimal) {
			number = number/10;
			decimal = false;
		} else {
			number = 999;
		}
	}

	uint8_t hundreds = (uint8_t)(number/100);
	uint8_t remainder = number - (hundreds * 100);
	uint8_t tens = remainder/10;
	uint8_t units = remainder - (tens * 10);

	// Display most significant digit if required
	// and adjust the display origin accordingly
	if (number > 99) {
		offset = spacing;
		seven_segment(hundreds, X, Y, BLACK);
	}
	seven_segment(tens, X + offset, Y, BLACK);
    seven_segment(units, X + spacing + offset, Y, BLACK);

    // Display the decimal point as required
    if (decimal) {
    	Paint_DrawPoint(X + spacing + offset - 7, Y + 76, BLACK, DOT_PIXEL_4X4, DOT_FILL_AROUND);
    }
}

// Target level bar graph
// Draws a bar graph at the RHS of the display
// Expects the level to be in dB with a max of 99
// ----------------------------------------------
void bar_graph(uint8_t level) {
    UWORD colour[10] = {
        BLUE,
        BLUE,
        GREEN,
        GREEN,
        YELLOW,
        YELLOW,
        BRRED,
        BRRED,
        RED,
        RED  
    };

    UWORD X = 150;
    UWORD Y = 114;
    const UWORD rhs = 155;

    for (uint8_t bar = 0; bar < level; bar += 10) {
        Paint_DrawRectangle(X, Y, rhs, Y + 10, colour[bar/10], DOT_PIXEL_1X1, DRAW_FILL_FULL);
        Paint_DrawRectangle(X, Y, rhs, Y + 10, BLACK, DOT_PIXEL_1X1, DRAW_FILL_EMPTY);
        X -= 5;
        Y -= 12;
    }
}

// Battery level indicator with programmable min/max and redline values
// The actual length of the graphic is proportional to the min/max range
// ---------------------------------------------------------------------
void battery_level(uint8_t voltage, uint8_t min, uint8_t max, uint8_t redline, UWORD X, UWORD Y) {

    UWORD colour;
    uint8_t level;

    uint8_t size = (max - min) + 6;

    if (voltage <= redline) {
        colour = RED;
    } else {
        colour = GREEN;
    }

    if (voltage < min) {
        voltage = min;
    } else if (voltage > max) {
        voltage = max;
    }
    
    level = voltage - min;

    Paint_DrawRectangle(X, Y, X + size, Y + 15, BLACK, DOT_PIXEL_1X1, DRAW_FILL_EMPTY);
    Paint_DrawRectangle(X + size, Y + 3, X + size + 3, Y + 12, BLACK, DOT_PIXEL_1X1, DRAW_FILL_EMPTY);
    Paint_DrawRectangle(X + 2, Y + 2, X + 2 + level, Y + 14, colour, DOT_PIXEL_1X1, DRAW_FILL_FULL);
    Paint_DrawLine(X + 3 + level, Y + 2, X + 3 + level, Y + 13, BLACK, DOT_PIXEL_1X1, LINE_STYLE_SOLID);
}