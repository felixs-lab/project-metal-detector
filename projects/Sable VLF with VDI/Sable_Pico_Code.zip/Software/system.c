// ============================================================================
// Sable V1.0 - VLF metal detector
// System level functions
// Graham Oliver
// 10/08/2023
// ============================================================================

#include "system.h"

uint audio_slice;


//	---------------------------------------------------------------------------
//	System initialisation function
// ----------------------------------------------------------------------------
void sys_init(void) {

	// Initialise stdio functions e.g. printf etc.
	// -------------------------------------------
	stdio_init_all();

	//	Force PSU into PWM mode to reduce noise from Pico
	//	-------------------------------------------------
	gpio_init(PWM_MODE_PIN);
	gpio_set_dir(PWM_MODE_PIN, GPIO_OUT);
	gpio_put(PWM_MODE_PIN, 1);

	// Turn on the local LED so we know it's working
	// ---------------------------------------------
	gpio_init(LED_PIN);
	gpio_set_dir(LED_PIN, GPIO_OUT);
	gpio_put(LED_PIN, 1);

	// Initialise LED's 1 to 8 to off (GPIO 0 - 7)
	// -------------------------------------------
	for (uint gpio = 0; gpio < 8; gpio++) {
		gpio_init(gpio);
		gpio_set_dir(gpio, GPIO_OUT);
		gpio_put(gpio, 0);
	}

	// Turn on LED 8 so we know it's working
	// -------------------------------------
	gpio_put(LED8_PIN, 1);
}

// Initialise the audio output to 424Hz (As per Raptor)
// ----------------------------------------------------
void audio_init(void) {
	gpio_set_function(AUDIO_PIN, GPIO_FUNC_PWM);
	audio_slice = pwm_gpio_to_slice_num(AUDIO_PIN);
	pwm_set_clkdiv(audio_slice, 125);
	audio_frequency(424);
	pwm_set_enabled(audio_slice, true);
}

// Set audio frequency
// -------------------
void audio_frequency(uint16_t frequency) {
	uint16_t wrap = 1000000/frequency;
	uint16_t level = wrap/2;
	pwm_set_wrap(audio_slice, wrap);
	pwm_set_chan_level(audio_slice, PWM_CHAN_A, level);
}
