// ============================================================================
// Sable V1.0 - VLF metal detector
// Programmable parameter functions
// Also provides a set of global variables which may be used by any module,
// and provides the multi-core queues to pass messages and data between cores
// Graham Oliver
// 10/08/2023
// ============================================================================

#include "parms.h"

// Programmable parameters defaults
// --------------------------------
union Parms parm = {
	250,	// R sample pulse delay in 10nSec increments
	750,	// X sample pulse delay in 10nSec increments
	15,		// Sensitivity threshold percentage
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0xaaaaaaaa
};

bool update_flash = false;

#define FLASH_TARGET_OFFSET (2044 * 1024)
const uint8_t *flash_target_contents = (const uint8_t *) (XIP_BASE + FLASH_TARGET_OFFSET);

// Multicore queueing system
// -------------------------
queue_t lcd_view_queue;
queue_t battery_voltage_queue;
queue_t target_queue;

// Function to store the parameters to flash
// Note:
// The 2nd core should be reset before running this function
// ---------------------------------------------------------
void parms_store(void) {
	multicore_reset_core1();
	uint32_t ints = save_and_disable_interrupts();
	flash_range_erase(FLASH_TARGET_OFFSET, FLASH_PAGE_SIZE);
	flash_range_program(FLASH_TARGET_OFFSET, parm.flash, FLASH_PAGE_SIZE);
	restore_interrupts(ints);
	multicore_launch_core1(core1_main);
}

// Function to restore the parameters from Flash if they exist
// -----------------------------------------------------------
void parms_restore(void) {
	if (flash_target_contents[255] == 0xaa) {
		for (size_t i = 0; i < FLASH_PAGE_SIZE; ++i) {
			parm.flash[i] = flash_target_contents[i];
		}
	}
}

// Function to initialise the multi-core queues
// --------------------------------------------
void queues_init(void) {
	queue_init(&lcd_view_queue, sizeof(uint8_t), 8);
	queue_init(&battery_voltage_queue, sizeof(uint8_t), 1);
	queue_init(&target_queue, sizeof(target_entry_t), 1);
}

