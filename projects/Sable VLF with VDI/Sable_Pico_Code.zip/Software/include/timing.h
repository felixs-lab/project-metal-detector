// ============================================================================
// Sable V1.0 - VLF metal detector
// Header file for "timing.c"
// Graham Oliver
// 10/08/2023
// ============================================================================

#ifndef __TIMING_H
#define __TIMING_H

#include "hardware/pio.h"
#include "sable.pio.h"
#include "sable.h"
#include "parms.h"

void timing_init(void);
void r_set(uint delay);
void x_set(uint delay);
void sens_set(uint width);


#endif