// ============================================================================
// Sable V1.0 - VLF metal detector
// Header file for "parms.c"
// Graham Oliver
// 10/08/2023
// ============================================================================

#ifndef __PARMS_H
#define __PARMS_H

#include <stdio.h>
#include "pico/util/queue.h"
#include "pico/multicore.h"
#include "hardware/flash.h"
#include "hardware/timer.h"
#include "sable.h"

// Enumerated names for programmable parameters
// --------------------------------------------
enum {
	R_DELAY,
	X_DELAY,
	THRESH
};

// Programmable parameters
// -----------------------
union Parms {
	uint32_t vars[64];
	uint8_t flash[256];
};
extern union Parms parm;
extern bool update_flash;

// Multicore queueing system
// -------------------------
extern queue_t lcd_view_queue;
extern queue_t battery_voltage_queue;
extern queue_t target_queue;

typedef struct {
	uint8_t id;
	uint8_t level;
} target_entry_t;

// Enumerated names for LCD view types
// -----------------------------------
enum {
	BLANK_VIEW,
	SPLASH_VIEW,
	DETECT_VIEW,
	MENU_VIEW,
	EDIT_VIEW
};

// Function prototypes
// -------------------
void core1_main();
void parms_store(void);
void parms_restore(void);
void queues_init(void);

#endif