// ============================================================================
// Sable V1.0 - VLF metal detector
// Header file for "system.c"
// Graham Oliver
// 10/08/2023
// ============================================================================

#ifndef __SYSTEM_H
#define __SYSTEM_H

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/pwm.h"
#include "parms.h"
#include "sable.h"

void sys_init(void);
void audio_init(void);
void audio_frequency(uint16_t frequency);
void sens_init(void);
void sens_thresh(uint32_t threshold);

#endif
