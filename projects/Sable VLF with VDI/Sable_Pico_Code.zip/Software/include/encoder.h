// ============================================================================
// Sable V1.0 - VLF metal detector
// Header file for "encoder.c"
// Graham Oliver
// 11/08/2023
// ============================================================================

#ifndef __ENCODER_H
#define __ENCODER_H

#include "hardware/irq.h"
#include "sable.pio.h"
#include "sable.h"
#include "system.h"
#include "parms.h"
#include "timing.h"

// Enumerated encoder processor states
enum {
	IDLE_STATE,
	R_EDIT_STATE,
	X_EDIT_STATE,
	S_EDIT_STATE
};

void encoder_init(void);
void encoder_handler(void);
void encoder_process(bool up, bool down, bool click, bool double_click);
bool get_state(uint sm);

#endif