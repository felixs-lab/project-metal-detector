// ============================================================================
// Sable V1.0 - VLF metal detector
// Header file for "lcd.c"
// Graham Oliver
// 17/08/2023
// ============================================================================

#ifndef __LCD_H
#define __LCD_H

#include "LCD_1in8.h"
#include "GUI_Paint.h"
#include "parms.h"
#include "sable.h"

// 7-Segment segment half-height and length
#define SEG_H 4
#define SEG_L 35

bool lcd_init(void);
void lcd_run(void);
void splash_view(void);
void detect_view(void);
void border(UWORD colour);
void segment(UWORD X, UWORD Y, uint8_t horizontal, UWORD colour);
void seven_segment(uint8_t digit, UWORD X, UWORD Y, UWORD colour);
void display_number(uint16_t number, UWORD X, UWORD Y, bool decimal, bool center);
void bar_graph(uint8_t level);
void battery_level(uint8_t voltage, uint8_t min, uint8_t max, uint8_t redline, UWORD X, UWORD Y);

#endif