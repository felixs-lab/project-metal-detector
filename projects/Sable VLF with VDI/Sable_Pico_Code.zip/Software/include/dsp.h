// ============================================================================
// Sable V1.0 - VLF metal detector
// Header file for "dsp.c"
// Graham Oliver
// 18/08/2023
// ============================================================================

#ifndef __DSP_H
#define __DSP_H

#include <math.h>
#include "hardware/pio.h"
#include "hardware/adc.h"
#include "sable.h"
#include "parms.h"
#include "system.h"

// Function prototypes
// -------------------
void dsp_init(void);
void dsp_run(void);
uint16_t get_adc(uint channel);
void check_battery(void);
void identify(void);

#endif