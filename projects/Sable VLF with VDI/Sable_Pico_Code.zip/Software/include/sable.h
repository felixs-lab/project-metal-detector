// ============================================================================
// Sable V1.0 - VLF metal detector
// Header file containing all Sable specific definitions, pinouts etc...
// Graham Oliver
// 10/08/2023
// ============================================================================

#ifndef __SABLE_H
#define __SABLE_H


// ----------------------------------------------------------------------------
// System pin definitions
// Note:
// -----
// This is the ONLY place where pins should be defined excepting for when the
// pin is hard-wired within a PIO assembly program, in which case it needs to
// be defined there as well. Please refer to "sable.pio" for PIO defines.
// ----------------------------------------------------------------------------

#define LED1_PIN 0
#define LED2_PIN 1
#define LED3_PIN 2
#define LED4_PIN 3
#define LED5_PIN 4
#define LED6_PIN 5
#define LED7_PIN 6
#define LED8_PIN 7
#define TXREF_PIN 15
#define AUDIO_PIN 16
#define SENS_PIN 17
#define PHB_PIN 18
#define PHA_PIN 19
#define SEL_PIN 20
#define X_SMPL_PIN 21
#define R_SMPL_PIN 22
#define PWM_MODE_PIN 23
#define LED_PIN 25
#define RVAL_PIN 26
#define XVAL_PIN 27
#define VBAT_PIN 28



#endif